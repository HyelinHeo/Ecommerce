<!DOCTYPE html>
<html>
<head>
	<title>WPAY 표준 메뉴리스트</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<style type="text/css">
		body { background-color: #efefef;}
		body, tr, td {font-size:9pt; font-family:굴림,verdana; color:#433F37; line-height:19px;}
		table, img {border:none}
	</style>
</head>
<body bgcolor="#FFFFFF" text="#242424" leftmargin=0 topmargin=15 marginwidth=0 marginheight=0 bottommargin=0 rightmargin=0>
	<div style="padding:10px;background-color:#f3f3f3;width:100%;font-size:13px;color: #ffffff;background-color: #000000;text-align: center">
		WPAY 표준
	</div>
	
	<table width="650" border="0" cellspacing="0" cellpadding="0" style="padding:10px;" align="center">
		<tr>
			<td bgcolor="6095BC" align="center" style="padding:10px">
				<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#FFFFFF" style="padding:20px">

					<tr>
						<td>
							이 페이지는 WPAY 표준 메뉴 리스트 입니다.<br/>
							<br/>

							<br/>
							테스트 하고자 하는 메뉴를 클릭 하여,<br/>
							테스트를 진행해 주시기 바랍니다.<br/>
							<br/><br/>
						</td>
					</tr>
					<tr>
						<td>
							<table >
								<tr>
									<td style="text-align:left;">
										
											<div style="border:2px #dddddd double;padding:10px;background-color:#f3f3f3;">
												
												<a  target="_blank" href="stdWpayMemCiForm.php">1. WPAY 표준 회원가입요청(CI 필수)</a>
													
												<br/><br/>
												<a  target="_blank" href="stdWpayMemForm.php" >2. WPAY 표준 회원가입요청(CI 옵션)</a>
												
												<br/><br/>
												<a  target="_blank" href="stdWpayPayForm.php" >3. WPAY 표준 결제인증요청</a>
												
												<br/><br/>
												<a  target="_blank" href="stdWpayPayapplForm.php" >4. WPAY 표준 결제승인요청</a>
												
												<br/><br/>
												<a  target="_blank" href="stdWpayPaycancelForm.php" >5. WPAY 표준 결제취소요청</a>
												
												<br/><br/>
												<a  target="_blank" href="stdWpayMypageForm.php" >4. WPAY 표준 마이페이지</a>

											</div>
									</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</form>
</body>
</html>
